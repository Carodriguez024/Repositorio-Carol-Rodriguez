# s14_Mediaqueries-Carol-Rodriguez

A Pen created on CodePen.

Original URL: [https://codepen.io/CAROL-AILEN-RODRIGUEZRAMOS/pen/zxrwVRp](https://codepen.io/CAROL-AILEN-RODRIGUEZRAMOS/pen/zxrwVRp).

