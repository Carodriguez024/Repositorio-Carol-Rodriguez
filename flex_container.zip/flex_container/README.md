# flex_container

A Pen created on CodePen.

Original URL: [https://codepen.io/CAROL-AILEN-RODRIGUEZRAMOS/pen/dPGVRXW](https://codepen.io/CAROL-AILEN-RODRIGUEZRAMOS/pen/dPGVRXW).

